"use strict";

const mongoose = require("mongoose");
const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true,
  },
  price: {
    type: String,
    required: true
  } 
  //still need to Add Product Images in here too
});

productSchema.methods.getInfo = function() {
    return `Name: ${this.name} Description: ${this.description} Price: ${this.price}`;
  };

module.exports = mongoose.model("Product", productSchema);