"use strict";

// Import required libraries
const express = require("express"),
  app = express(),
  homeController = require("./controllers/homeController"),
  errorController = require("./controllers/errorController"),
  layouts = require("express-ejs-layouts");

// Import Mongoose rather than working with MongoDB directly
const mongoose = require("mongoose");

app.set("view engine", "ejs"); // Use EJS
app.set("port", process.env.PORT || 3000); // Set port to PORT env variable or 3000
app.use(express.urlencoded({extended: false})); // Use built-in middleware to parse request body data from html forms (urlencoded)
app.use(express.json()); // Use built-in middleware to parse request body data in JSON format
app.use(layouts); // Tell the app that it should use express-ejs-layouts
app.use(express.static("public")); // Tell the app where to find static resources

// Routes
app.get("/", (req, res) => {
  //res.sendFile(__dirname+"/views/index.html");
  res.render("index");
});
app.get("/about", homeController.showAbout);
app.get("/article", homeController.showArticle)
app.get("/contact", homeController.showContact);
app.get("/gardens", homeController.showGardens);
app.get("/index", homeController.showIndex);
app.get("/layout", homeController.showLayout);
app.get("/news", homeController.showNews);
app.get("/plants", homeController.showPlants);



app.listen(app.get("port"), () => {
  console.log(`Server running at http://localhost:${app.get("port")}`);
});
